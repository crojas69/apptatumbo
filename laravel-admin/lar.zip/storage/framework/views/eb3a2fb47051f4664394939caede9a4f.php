<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Registros Site Survey</h2>
    <table id="surveyTable" class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Usuario</th>
                <th>Sitio</th>
                <th>Fecha</th>
                <th>Equipo</th>
                <th>Objetivos</th>
                <th>Observaciones</th>
                <th>Formación</th>
                <th>Preventivo</th>
                <th>Correctivo</th>
                <th>BOM</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($s->id); ?></td>
                <td><?php echo e($s->user->name ?? 'Sin asignar'); ?></td>
                <td><?php echo e($s->site_name); ?></td>
                <td><?php echo e($s->site_date); ?></td>
                <td><?php echo e($s->team); ?></td>
                <td><?php echo e($s->objetivos); ?></td>
                <td><?php echo e($s->observaciones); ?></td>
                <td><?php echo e($s->formacion); ?></td>
                <td><?php echo e($s->mant_preventivo); ?></td>
                <td><?php echo e($s->mant_correctivo); ?></td>
                <td><?php echo e($s->bom_detalle); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- DataTables + Export Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<script>
    $(document).ready(function () {
        $('#surveyTable').DataTable({
            dom: 'Bfrtip',
            buttons: ['excel', 'csv', 'print']
        });

        $('#usersTable').DataTable({
            dom: 'Bfrtip',
            buttons: ['excel', 'csv', 'print']
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\apptatumbo\laravel-admin\resources\views/dashboard.blade.php ENDPATH**/ ?>