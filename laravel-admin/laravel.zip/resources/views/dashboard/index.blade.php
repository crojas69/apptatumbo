<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h2>Panel del usuario: {{ auth()->user()->name }}</h2>

    <form method="POST" action="/logout">
        @csrf
        <button type="submit">Cerrar sesión</button>
    </form>

    <h3>Mis encuestas</h3>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Datos</th>
            <th>Fecha</th>
        </tr>
        @foreach ($surveys as $survey)
            <tr>
                <td>{{ $survey->id }}</td>
                <td>{{ $survey->data }}</td>
                <td>{{ $survey->created_at }}</td>
            </tr>
        @endforeach
    </table>
</body>
</html>
