

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Usuarios</h2>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary mb-3">Crear Usuario</a>
    <table class="table table-bordered">
        <thead><tr><th>Nombre</th><th>Email</th></tr></thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><td><?php echo e($user->name); ?></td><td><?php echo e($user->email); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\apptatumbo\laravel-admin\resources\views/users/index.blade.php ENDPATH**/ ?>