

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Registros de Visit Approval</h2>
    <table id="visitApprovalTable" class="table table-striped table-responsive">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre del Sitio</th>
                <th>Fecha de Visita</th>
                <th>RSSI</th>
                <th>Resultados Conectividad</th>
                <th>Conclusión</th>
                <th>Firma del Supervisor</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $visitApprovals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($v->id); ?></td>
                <td><?php echo e($v->site_name); ?></td>
                <td><?php echo e($v->visit_date); ?></td>
                <td><?php echo e($v->rssi); ?></td>
                <td><?php echo e($v->connectivity_results); ?></td>
                <td><?php echo e($v->conclusion); ?></td>
                <td>
                    <img src="<?php echo e($v->signature); ?>" alt="Firma" style="width: 100px;">
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- DataTables + Export Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<script>
    $(document).ready(function () {
        $('#visitApprovalTable').DataTable({
            dom: 'Bfrtip',
            buttons: ['excel', 'csv', 'print']
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\apptatumbo\laravel-admin\resources\views/visit-approval.blade.php ENDPATH**/ ?>