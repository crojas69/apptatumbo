<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Dashboard</h2>
    
    <!-- Gráfico de Site Survey -->
    <h3>Gráfico de Site Survey</h3>
    <canvas id="siteSurveyChart"></canvas>
    
    <!-- Gráfico de Visit Approval -->
    <h3>Gráfico de Visit Approval</h3>
    <canvas id="visitApprovalChart"></canvas>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- DataTables + Export Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<script>
    $(document).ready(function () {
        $('#surveyTable').DataTable({
            dom: 'Bfrtip',
            buttons: ['excel', 'csv', 'print']
        });

        $('#visitApprovalTable').DataTable({
            dom: 'Bfrtip',
            buttons: ['excel', 'csv', 'print']
        });

        // Gráfico de Site Survey
        var siteSurveyData = {
            labels: <?php echo json_encode($months, 15, 512) ?>,
            datasets: [{
                label: 'Cantidad de Site Surveys',
                data: <?php echo json_encode($counts, 15, 512) ?>,
                borderColor: 'rgba(75, 192, 192, 1)',
                fill: false
            }]
        };

        var ctx1 = document.getElementById('siteSurveyChart').getContext('2d');
        new Chart(ctx1, {
            type: 'line',
            data: siteSurveyData
        });

        // Gráfico de Visit Approval
        var visitApprovalData = {
            labels: <?php echo json_encode($labels, 15, 512) ?>,
            datasets: [{
                label: 'Cantidad de Visit Approvals',
                data: <?php echo json_encode($data, 15, 512) ?>,
                backgroundColor: ['rgba(75, 192, 192, 0.2)', 'rgba(255, 99, 132, 0.2)'],
                borderColor: ['rgba(75, 192, 192, 1)', 'rgba(255, 99, 132, 1)'],
                borderWidth: 1
            }]
        };

        var ctx2 = document.getElementById('visitApprovalChart').getContext('2d');
        new Chart(ctx2, {
            type: 'pie',
            data: visitApprovalData
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\apptatumbo\laravel-admin\resources\views/dashboard.blade.php ENDPATH**/ ?>