
 
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Crear Usuario</h2>
    <form action="<?php echo e(route('users.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mb-2">
            <label>Nombre</label>
            <input type="text" name="name" class="form-control" required />
        </div>
        <div class="form-group mb-2">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required />
        </div>
        <div class="form-group mb-2">
            <label>Contraseña</label>
            <input type="password" name="password" class="form-control" required />
        </div>
        <button type="submit" class="btn btn-success">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\apptatumbo\laravel-admin\resources\views/users/create.blade.php ENDPATH**/ ?>