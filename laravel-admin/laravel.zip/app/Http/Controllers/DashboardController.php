<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\SiteSurvey;

class DashboardController extends Controller
{
    public function index()
    {
        $surveys = SiteSurvey::where('user_id', Auth::id())->get();
        return view('dashboard.index', compact('surveys'));
    }
}
