<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // Método para el login
    public function login(Request $request)
    {
        // Validación de las credenciales
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        // Intentar autenticar con las credenciales proporcionadas
        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $user = Auth::user();
            
            // Si la autenticación es exitosa, generar un token
            $token = $user->createToken('YourAppName')->plainTextToken;

            // Retornar el token como respuesta
            return response()->json(['token' => $token], 200);
        }

        // Si las credenciales son incorrectas, retornar un error
        return response()->json(['message' => 'Unauthorized'], 401);
    }

    // Método de registro (opcional si deseas registrar usuarios)
    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return response()->json(['message' => 'User created successfully'], 201);
    }

    // Método para hacer logout (invalidar el token)
    public function logout(Request $request)
    {
        // Invalidar el token
        Auth::user()->tokens->each(function ($token) {
            $token->delete();
        });

        return response()->json(['message' => 'Logged out successfully'], 200);
    }
}
