import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { Capacitor } from '@capacitor/core';
import { SQLiteService } from './sqlite.service'; 
@Injectable({ providedIn: 'root' })
export class StorageService {
  private _storage: Storage | null = null;
  private isNative: boolean;

  private SURVEY_STORAGE_KEY = 'local_surveys';
  private ALT_STORAGE_KEY = 'offlineSurveys';

  constructor(private storage: Storage, private sqliteService: SQLiteService) {
    this.isNative = Capacitor.isNativePlatform();
    this.init();
  }

  /**
   * Inicializa el almacenamiento según la plataforma
   */
  private async init() {
    if (this.isNative) {
      // Usar SQLite en dispositivos nativos (iOS/Android)
      await this.sqliteService.initDB();
    } else {
      // Usar Ionic Storage en la web
      this._storage = await this.storage.create();
    }
  }

  /**
   * Guarda una encuesta en la clave local 'local_surveys' (en web o móvil)
   */
  async saveSurveyOffline(survey: any) {
    const surveys = await this._storage?.get(this.SURVEY_STORAGE_KEY) ?? [];
    surveys.push(survey);
    await this._storage?.set(this.SURVEY_STORAGE_KEY, surveys);
  }

  /**
   * Alternativa: Guarda usando la clave 'offlineSurveys'
   */
  async saveOfflineSurvey(data: any) {
    const surveys = await this._storage?.get(this.ALT_STORAGE_KEY) ?? [];
    surveys.push(data);
    await this._storage?.set(this.ALT_STORAGE_KEY, surveys);
  }

  /**
   * Recupera encuestas guardadas en 'local_surveys' (web o móvil)
   */
  async getOfflineSurveys(): Promise<any[]> {
    return await this._storage?.get(this.SURVEY_STORAGE_KEY) ?? [];
  }

  /**
   * Elimina las encuestas subidas (clave 'local_surveys')
   */
  async removeUploadedSurveys() {
    return this._storage?.remove(this.SURVEY_STORAGE_KEY);
  }

  /**
   * Limpia la otra clave alternativa 'offlineSurveys'
   */
  async clearOfflineSurveys() {
    await this._storage?.remove(this.ALT_STORAGE_KEY);
  }

  /**
   * Obtiene el token si lo estás guardando por separado
   */
  async getToken(): Promise<string | null> {
    if (!this._storage) {
      this._storage = await this.storage.create(); // asegúrate de que se haya inicializado correctamente
    }
    return await this._storage?.get('token') ?? null;
  }

  /**
   * Guarda un token
   */
  async setToken(token: string) {
    if (!this._storage) {
      this._storage = await this.storage.create(); // asegúrate de que se haya inicializado correctamente
    }
    await this._storage?.set('token', token);
  }

  /**
   * Borra completamente todos los datos del storage
   */
  async clearAllStorage() {
    if (this.isNative) {
      // Si estamos en móvil, borra usando SQLite
      await this.sqliteService.clearDB();
    } else {
      // En la web, borra usando Ionic Storage
      await this._storage?.clear();
    }
  }
}
