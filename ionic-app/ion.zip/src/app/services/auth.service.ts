import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Storage } from '@ionic/storage-angular';
import { Observable, from, of } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'http://localhost:8000/api'; // Ajusta si cambia el endpoint

  constructor(private http: HttpClient, private storage: Storage) {}

  /** Lógica de inicio de sesión **/
  login(email: string, password: string): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/login`, { email, password })
      .pipe(
        tap(async (response: any) => {
          await this.setToken(response.token);
        }),
        catchError((error) => {
          console.error('Login failed:', error);
          return of(null);
        })
      );
  }


  /** Obtiene el token **/
  async getToken(): Promise<string | null> {
    await this.storage.create(); // inicializa si es necesario
    return await this.storage.get('token');
  }

  async setToken(token: string) {
    await this.storage.create();
    await this.storage.set('token', token);
  }

  /** Verifica si el usuario está autenticado **/
  async isAuthenticated(): Promise<boolean> {
    const token = await this.getToken();
    return !!token;
  }

  /** Elimina el token al cerrar sesión **/
  async logout(): Promise<void> {
    await this.storage.remove('token');
  }

  sendSurvey(data: any) {
    return this.http.post(`${this.apiUrl}/site-surveys`, data); // o el endpoint real
  }
}
