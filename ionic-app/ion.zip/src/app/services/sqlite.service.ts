import { Injectable } from '@angular/core';
import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection, SQLiteDBConnection } from '@capacitor-community/sqlite';
import { defineCustomElements } from 'jeep-sqlite/loader';

@Injectable({ providedIn: 'root' })
export class SQLiteService {
  private dbName = 'survey_db';
  private sqlite = new SQLiteConnection(CapacitorSQLite);
  private db: SQLiteDBConnection | null = null;

  constructor() {
    this.setupWebPlatform();
  }

  private async setupWebPlatform() {
    if (Capacitor.getPlatform() === 'web') {
      defineCustomElements(window);
      try {
        await CapacitorSQLite.initWebStore();
        console.log('[SQLite] Web store initialized');
      } catch (error) {
        console.error('[SQLite] Failed to initialize web store', error);
      }
    }
  }

  async initDB() {
    try {
      this.db = await this.sqlite.createConnection(this.dbName, false, 'no-encryption', 1, false);
      await this.db.open();
      await this.db.execute(`
        CREATE TABLE IF NOT EXISTS site_surveys (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          data TEXT
        );
      `);
      console.log('[SQLite] DB initialized');
    } catch (error) {
      console.error('[SQLite] DB init error:', error);
    }
  }

  async saveData(data: any) {
    if (!this.db) return;
    try {
      await this.db.run(
        `INSERT INTO site_surveys (data) VALUES (?)`,
        [JSON.stringify(data)]
      );
      console.log('[SQLite] Data saved');
    } catch (error) {
      console.error('[SQLite] Save error:', error);
    }
  }

  async getData(): Promise<any[]> {
    if (!this.db) return [];
    try {
      const result = await this.db.query(`SELECT * FROM site_surveys`);
      return result.values || [];
    } catch (error) {
      console.error('[SQLite] Get error:', error);
      return [];
    }
  }

  async clearDB() {
    try {
      await this.sqlite.closeConnection(this.dbName, false); // <- CORRECTO: se requieren 2 args
      console.log('[SQLite] Connection closed');
    } catch (error) {
      console.error('[SQLite] Clear error:', error);
    }
  }
}
