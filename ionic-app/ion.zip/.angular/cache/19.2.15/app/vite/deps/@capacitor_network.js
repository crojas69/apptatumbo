import {
  registerPlugin
} from "./chunk-FY32TZO5.js";
import "./chunk-5EGPVVY4.js";

// node_modules/@capacitor/network/dist/esm/index.js
var Network = registerPlugin("Network", {
  web: () => import("./web-IASFRGSM.js").then((m) => new m.NetworkWeb())
});
export {
  Network
};
//# sourceMappingURL=@capacitor_network.js.map
