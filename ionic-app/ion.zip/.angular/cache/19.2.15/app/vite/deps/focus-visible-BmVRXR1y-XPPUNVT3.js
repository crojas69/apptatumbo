import {
  startFocusVisible
} from "./chunk-TQ5OEMTL.js";
import "./chunk-5EGPVVY4.js";
export {
  startFocusVisible
};
